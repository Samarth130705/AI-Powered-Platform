"""One entry per feature: request contract, response contract, prompt, image policy."""
from dataclasses import dataclass
from typing import Callable, Literal, Optional
import httpx
from fastapi import HTTPException
from pydantic import BaseModel
from . import schemas as s

COMMON = ("Be specific and practical. Never invent details you cannot see or were not given; "
          "say what is uncertain and lower your confidence instead. You support professionals and do not replace "
          "a licensed engineer, valuer or safety officer.")


@dataclass
class Module:
    request: type[BaseModel]
    response: type[BaseModel]
    system: str
    image: Literal["none", "optional", "required"] = "none"
    enrich: Optional[Callable[[BaseModel], dict]] = None


def fetch_forecast(req: s.WeatherRequest) -> dict:
    try:
        r = httpx.get("https://api.open-meteo.com/v1/forecast", timeout=8, params={
            "latitude": req.latitude, "longitude": req.longitude, "timezone": "auto", "forecast_days": 5,
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,weather_code"})
        r.raise_for_status()
        return r.json()["daily"]
    except (httpx.HTTPError, KeyError):
        raise HTTPException(502, "Could not fetch the weather forecast. Try again in a moment.")


MODULES: dict[str, Module] = {
    "safety": Module(s.SafetyRequest, s.SafetyReport, image="required", system=(
        "You are a construction site safety inspector reviewing one photo. Check PPE (helmets, vests, footwear, "
        "harnesses), work at height, scaffolding, housekeeping, machinery, electrical hazards and excavations. "
        "List only violations visible in the image. Score 100 for no visible issues. " + COMMON)),
    "cracks": Module(s.CrackRequest, s.CrackReport, image="required", system=(
        "You are a structural diagnostics assistant analysing a photo of cracks in a building element. Classify the "
        "pattern, estimate width using visible scale references only, suggest likely causes (shrinkage, settlement, "
        "overload, thermal, corrosion) and recommended next steps. Set needs_engineer_inspection to true for "
        "structural_risk of medium or above. " + COMMON)),
    "valuation": Module(s.ValuationRequest, s.ValuationReport, image="optional", system=(
        "You are a real estate valuation assistant. Estimate market value from the property details (and photo if "
        "given) using location, size, age, condition and amenities. Give a range, state assumptions, and use the "
        "requested currency. This is an indicative estimate, not a certified valuation. " + COMMON)),
    "planning": Module(s.PlanRequest, s.ProjectPlan, system=(
        "You are a construction project planner. Produce phases in build order with realistic durations, task lists, "
        "dependencies by phase name, crew needs, a cost breakdown whose share_percent values sum to 100, and the top "
        "risks with mitigations. Fit the plan to the stated budget and duration when given. " + COMMON)),
    "assistant": Module(s.AssistantRequest, s.AssistantReply, image="optional", system=(
        "You are a daily assistant for a site engineer or supervisor. Answer the question, then list concrete action "
        "items for today and any follow-up questions that would sharpen the advice. " + COMMON)),
    "weather": Module(s.WeatherRequest, s.WeatherAdvisory, enrich=fetch_forecast, system=(
        "You are a weather-aware construction advisor. Using the 5-day forecast in live_data (weather_code uses WMO "
        "codes), advise on each planned activity: concreting, excavation, crane lifts, roofing, painting and similar "
        "are sensitive to rain, heat and wind. " + COMMON)),
    "knowledge": Module(s.KnowledgeRequest, s.KnowledgeAnswer, system=(
        "You are a construction knowledge assistant covering materials, methods, codes and practice. Tune depth to "
        "the requested level. Name relevant standards (for example IS, BIS, ACI, Eurocode) only when you are sure "
        "they apply, and put limits of your answer in caveats. " + COMMON)),
}
