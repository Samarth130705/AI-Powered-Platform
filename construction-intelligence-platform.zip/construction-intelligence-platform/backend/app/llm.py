"""Thin wrapper around the multimodal LLM. Sends text + optional image, forces JSON,
validates against a Pydantic schema, and retries once with the validation error."""
import base64, json, os, re
from typing import Optional
from dotenv import load_dotenv
from fastapi import HTTPException
from pydantic import BaseModel
import anthropic

load_dotenv()
MODEL = os.getenv("LLM_MODEL", "claude-sonnet-5-5")
_client: Optional[anthropic.Anthropic] = None


def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        if not os.getenv("ANTHROPIC_API_KEY"):
            raise HTTPException(503, "ANTHROPIC_API_KEY is not set. Add it to backend/.env and restart the server.")
        _client = anthropic.Anthropic()
    return _client


def _extract_json(text: str) -> str:
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    start, end = text.find("{"), text.rfind("}")
    return text[start:end + 1] if start != -1 and end != -1 else text


def run_llm(system: str, context: dict, schema: type[BaseModel],
            image: Optional[bytes] = None, media_type: Optional[str] = None) -> BaseModel:
    system = (
        f"{system}\n\nReturn ONLY one JSON object that matches this JSON Schema. "
        f"No prose, no markdown fences.\n{json.dumps(schema.model_json_schema())}"
    )
    content = []
    if image:
        content.append({"type": "image", "source": {
            "type": "base64", "media_type": media_type, "data": base64.b64encode(image).decode()}})
    content.append({"type": "text", "text": json.dumps(context, ensure_ascii=False)})
    messages = [{"role": "user", "content": content}]

    last_error = ""
    for _ in range(2):
        try:
            msg = _get_client().messages.create(model=MODEL, max_tokens=2500, system=system, messages=messages)
        except anthropic.APIError as e:
            raise HTTPException(502, f"The AI service returned an error: {e}")
        text = "".join(b.text for b in msg.content if b.type == "text")
        try:
            return schema.model_validate_json(_extract_json(text))
        except ValueError as e:  # pydantic.ValidationError subclasses ValueError
            last_error = str(e)
            messages += [{"role": "assistant", "content": text},
                         {"role": "user", "content": f"That JSON failed validation: {last_error}\nReturn corrected JSON only."}]
    raise HTTPException(502, "The AI response did not match the expected format. Try again.")
