# AI-Powered Multimodal Construction Intelligence Platform

React.js frontend + FastAPI backend + multimodal LLM. Seven modules share one pipeline:

```
React form (text + optional image)
   -> POST /api/<module>  (multipart: JSON `payload` + `image`)
   -> Pydantic request validation
   -> optional live-data enrichment (e.g. weather forecast)
   -> multimodal LLM call, forced to return JSON
   -> Pydantic response validation (one automatic retry on mismatch)
   -> typed JSON back to React
```

## Modules

| Route | Input | Output contract |
|---|---|---|
| `POST /api/safety` | site photo (required), notes | `SafetyReport`: score, violations with severity and corrective action |
| `POST /api/cracks` | crack photo (required), element, notes | `CrackReport`: patterns, causes, structural risk, engineer-inspection flag |
| `POST /api/valuation` | property details, photo optional | `ValuationReport`: estimate, range, price per sq ft, assumptions |
| `POST /api/planning` | project brief | `ProjectPlan`: phases, resources, cost split, risks |
| `POST /api/assistant` | question, context, photo optional | `AssistantReply`: answer, action items, follow-ups |
| `POST /api/weather` | latitude, longitude, activities | `WeatherAdvisory`: per-activity go / caution / postpone (live Open-Meteo data) |
| `POST /api/knowledge` | question, depth | `KnowledgeAnswer`: answer, key points, standards, caveats |

`GET /api/contracts/<module>` returns the JSON Schemas for each module. `GET /api/health` lists modules.

## Run it

```bash
# backend (Python 3.10+)
cd backend
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # then add ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
python -m pytest                                       # contract tests, no API key needed

# frontend (Node 18+), in a second terminal
cd frontend
npm install
npm run dev                                            # http://localhost:5173
```

## Where to change things

- **Add or edit a module:** `backend/app/schemas.py` (contracts) and `backend/app/modules.py` (prompt + image policy), then add an entry to `MODULES` in `frontend/src/App.jsx`. The panel and result view are generic.
- **Swap the model:** set `LLM_MODEL` in `backend/.env`. Only `backend/app/llm.py` talks to the provider.
- **Production hardening:** auth, rate limiting, image storage, audit log of AI outputs, and a human-review step for safety and structural findings.

## Limits to state in your report

Outputs are advisory. Crack, safety and valuation results come from a single photo or form and are not a substitute for a structural engineer, site safety officer or certified valuer.
